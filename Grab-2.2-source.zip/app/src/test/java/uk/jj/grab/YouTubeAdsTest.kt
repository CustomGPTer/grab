package uk.jj.grab

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** The YouTube advert rules: what is accepted, what is refused, and which copy wins. */
class YouTubeAdsTest {

    private fun asset(name: String) = File("src/main/assets/$name").readText()
    private fun rules(change: (JSONObject) -> Unit = {}) = JSONObject(asset("yt_rules.json")).also(change).toString()

    @Test fun `the rules shipped in the app pass the check unchanged`() {
        val r = YouTubeAds.validate(asset("yt_rules.json"))
        assertNotNull(r)
        val shipped = JSONObject(asset("yt_rules.json"))
        for (key in shipped.keys()) assertEquals(key, shipped.get(key).toString(), r!!.get(key).toString())
    }

    @Test fun `a file in another layout is refused`() {
        assertNull(YouTubeAds.validate(rules { it.put("v", 2) }))
        assertNull(YouTubeAds.validate(rules { it.remove("rev") }))
        assertNull(YouTubeAds.validate("not json"))
        assertNull(YouTubeAds.validate("[]"))
    }

    @Test fun `anything that is not a plain name, path or selector is refused`() {
        assertNull(YouTubeAds.validate(rules { it.getJSONArray("keys").put("a;alert(1)") }))
        assertNull(YouTubeAds.validate(rules { it.getJSONArray("globals").put("x.y") }))
        assertNull(YouTubeAds.validate(rules { it.getJSONArray("paths").put("a..b") }))
        assertNull(YouTubeAds.validate(rules { it.getJSONArray("hide").put("body{display:none}") }))
        assertNull(YouTubeAds.validate(rules { it.getJSONArray("hide").put("a,b") }))
        assertNull(YouTubeAds.validate(rules { it.getJSONArray("skip").put("</style><script>") }))
        assertNull(YouTubeAds.validate(rules { it.getJSONArray("adClass").put("a b") }))
        assertNull(YouTubeAds.validate(rules { it.getJSONArray("keys").put(7) }))
        assertNull(YouTubeAds.validate(rules { it.getJSONArray("timers").getJSONObject(0).put("ms", 5) }))
        assertNull(YouTubeAds.validate(rules { it.getJSONArray("timers").getJSONObject(0).put("match", "\"+x+\"") }))
        assertNull(YouTubeAds.validate(rules { it.getJSONArray("drop").getJSONObject(0).put("when", "a b") }))
        assertNull(YouTubeAds.validate(rules { it.put("giveUpMs", 10) }))
    }

    @Test fun `fields Grab does not know are left out`() {
        val r = YouTubeAds.validate(rules { it.put("script", "alert(1)") })!!
        assertFalse(r.has("script"))
    }

    @Test fun `a saved copy is used only if it is at least as new as the built-in one`() {
        val built = YouTubeAds.validate(rules { it.put("rev", 5) })
        assertTrue(YouTubeAds.newer(YouTubeAds.validate(rules { it.put("rev", 6) }), built))
        assertTrue(YouTubeAds.newer(YouTubeAds.validate(rules { it.put("rev", 5).put("prune", false) }), built))
        assertFalse(YouTubeAds.newer(YouTubeAds.validate(rules { it.put("rev", 4) }), built))
        assertFalse(YouTubeAds.newer(null, built))
    }

    @Test fun `the script carries the rules, and the setting can switch removal off`() {
        val engine = asset("yt_ads.js")
        val r = YouTubeAds.validate(asset("yt_rules.json"))
        val on = YouTubeAds.build(engine, r, prune = true)!!
        val off = YouTubeAds.build(engine, r, prune = false)!!
        assertFalse(on.contains("/*RULES*/"))
        assertTrue(on.contains("\"prune\":true") && on.contains("adPlacements"))
        assertTrue(off.contains("\"prune\":false"))
        assertTrue(r!!.getBoolean("prune"))                       // building a script never alters the rules in use
        assertNull(YouTubeAds.build(engine, null, true))
        assertNull(YouTubeAds.build("no slot here", r, true))
    }
}
