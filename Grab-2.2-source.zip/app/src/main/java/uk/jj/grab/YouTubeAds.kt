package uk.jj.grab

import android.content.Context
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

/**
 * YouTube advert handling for the in-app browser.
 *
 * The work is done by a script (assets/yt_ads.js) that runs inside YouTube pages. What it looks for
 * (the names of YouTube's advert instructions, its Skip buttons and so on) is kept apart in a small
 * rules file, because YouTube renames these from time to time. A copy ships in the app; once a day Grab
 * also asks its own site for a newer one, so a rename can be dealt with without a new version of the app.
 *
 * The rules are data only. They are checked field by field against a strict pattern before use and can
 * never carry script of their own.
 */
object YouTubeAds {
    const val RULES_URL = "https://customgpter.github.io/grab/rules/youtube.json"

    /** The rules layout this version of the app understands. */
    const val FORMAT = 1
    private const val FILE = "yt_rules.json"
    private const val MAX_BYTES = 32 * 1024
    private const val DAY = 24 * 60 * 60 * 1000L
    private const val SLOT = "/*RULES*/null"

    /** Goes up each time the rules in use change, so open browsers install the new script. */
    val changed = MutableStateFlow(0)

    @Volatile private var engine = ""
    @Volatile private var rules: JSONObject? = null

    /** Revision of the rules in use (0 = none), and where they came from, for the page report. */
    val rev: Int get() = rules?.optInt("rev") ?: 0
    @Volatile var source = "none"
        private set

    fun init(ctx: Context) {
        try {
            engine = ctx.assets.open("yt_ads.js").bufferedReader().use { it.readText() }
            val bundled = validate(ctx.assets.open(FILE).bufferedReader().use { it.readText() })
            val saved = try { File(ctx.filesDir, FILE).takeIf { it.exists() }?.readText()?.let { validate(it) } } catch (_: Exception) { null }
            val useSaved = newer(saved, bundled)
            rules = if (useSaved) saved else bundled
            source = if (useSaved) "from the Grab site" else "built in"
        } catch (e: Exception) {
            Log.w(App.TAG, "advert rules: ${e.message}")
        }
        thread(name = "advert-rules", isDaemon = true) {
            try {
                if (System.currentTimeMillis() - Prefs.lastRulesCheck >= DAY) refresh(ctx)
            } catch (e: Exception) {
                Log.w(App.TAG, "advert rules update: ${e.message}")   // no connection: try again next start
            }
        }
    }

    /** The script to run in YouTube pages, with the rules in use written into it. Null if nothing is loaded. */
    fun script(): String? = build(engine, rules, Prefs.pruneYouTubeAds.value)

    internal fun build(engine: String, rules: JSONObject?, prune: Boolean): String? {
        if (rules == null || !engine.contains(SLOT)) return null
        val r = JSONObject(rules.toString())
        if (!prune) r.put("prune", false)
        return engine.replace(SLOT, r.toString())
    }

    /** A saved copy from the site is used only if it is at least as new as the copy shipped in the app. */
    internal fun newer(candidate: JSONObject?, base: JSONObject?): Boolean =
        candidate != null && (base == null || candidate.optInt("rev") >= base.optInt("rev"))

    private fun refresh(ctx: Context) {
        val c = URL(RULES_URL).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 10_000
            c.readTimeout = 10_000
            c.useCaches = false
            c.setRequestProperty("Accept", "application/json")
            if (c.responseCode != 200) return
            val bytes = c.inputStream.use { s ->
                val buf = java.io.ByteArrayOutputStream()
                val chunk = ByteArray(4096)
                while (buf.size() <= MAX_BYTES) {
                    val n = s.read(chunk)
                    if (n < 0) break
                    buf.write(chunk, 0, n)
                }
                buf.toByteArray()
            }
            Prefs.lastRulesCheck = System.currentTimeMillis()
            if (bytes.size > MAX_BYTES) return
            val fresh = validate(String(bytes, Charsets.UTF_8)) ?: return
            val current = rules
            if (!newer(fresh, current) || fresh.toString() == current?.toString()) return
            File(ctx.filesDir, FILE).writeText(fresh.toString())
            rules = fresh
            source = "from the Grab site"
            changed.value++
        } finally {
            c.disconnect()
        }
    }

    // ---- checking a rules file ----

    private val NAME = Regex("[A-Za-z0-9_]{1,60}")
    private val PATH = Regex("[A-Za-z0-9_]{1,60}(\\.[A-Za-z0-9_]{1,60}){0,11}")
    private val CLASS = Regex("[A-Za-z0-9_-]{1,40}")
    private val SELECTOR = Regex("[A-Za-z0-9 .#>_\\-\\[\\]=\"*:()~+^$|]{1,120}")
    private val NEEDLE = Regex("[A-Za-z0-9 _.,:;=>()\\[\\]{}-]{1,60}")

    /**
     * Reads a rules file and returns a clean copy holding only the fields Grab knows, each checked against
     * its pattern. Returns null if the file is not this app's format or anything in it is out of pattern.
     */
    internal fun validate(text: String): JSONObject? = try {
        val o = JSONObject(text)
        if (o.optInt("v") != FORMAT) null else {
            val rev = o.optInt("rev")
            val giveUp = o.optInt("giveUpMs", 8000)
            val out = JSONObject()
            out.put("v", FORMAT).put("rev", rev).put("prune", o.optBoolean("prune", false))
            out.put("keys", strings(o, "keys", 20, NAME))
            out.put("holders", strings(o, "holders", 20, NAME))
            out.put("globals", strings(o, "globals", 10, NAME))
            out.put("paths", strings(o, "paths", 20, PATH))
            out.put("adClass", strings(o, "adClass", 6, CLASS))
            out.put("skip", strings(o, "skip", 30, SELECTOR))
            out.put("hide", strings(o, "hide", 40, SELECTOR))
            out.put("drop", objects(o, "drop", 10) { d ->
                val list = d.optString("list")
                val whenPath = d.optString("when")
                require(PATH.matches(list) && PATH.matches(whenPath))
                JSONObject().put("list", list).put("when", whenPath)
            })
            out.put("timers", objects(o, "timers", 5) { t ->
                val ms = t.optInt("ms")
                val to = t.optInt("to", -1)
                val match = t.optString("match")
                require(ms in 1000..120_000 && to in 0..5000 && NEEDLE.matches(match))
                JSONObject().put("ms", ms).put("match", match).put("to", to)
            })
            out.put("giveUpMs", giveUp)
            if (rev in 1..1_000_000 && giveUp in 2000..60_000) out else null
        }
    } catch (_: Exception) { null }

    private fun strings(o: JSONObject, key: String, max: Int, pattern: Regex): JSONArray {
        val out = JSONArray()
        val a = o.optJSONArray(key) ?: return out
        require(a.length() <= max)
        for (i in 0 until a.length()) {
            val s = a.get(i)
            require(s is String && pattern.matches(s))
            out.put(s)
        }
        return out
    }

    private fun objects(o: JSONObject, key: String, max: Int, check: (JSONObject) -> JSONObject): JSONArray {
        val out = JSONArray()
        val a = o.optJSONArray(key) ?: return out
        require(a.length() <= max)
        for (i in 0 until a.length()) out.put(check(a.getJSONObject(i)))
        return out
    }
}
