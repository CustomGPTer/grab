/*
 * Grab - YouTube advert handling. Runs inside YouTube pages, before YouTube's own scripts where the
 * web view allows it. Everything it looks for comes from the rules object below (yt_rules.json, or the
 * newer copy fetched from the Grab site), so names can be updated without a new version of the app.
 *
 * 1. Removes the advert instructions from the player data, so no advert is scheduled.
 * 2. If an advert starts anyway: covers it, mutes it, jumps it to its end and presses Skip.
 * 3. Keeps a short timing log, shown in the page report.
 */
(function () {
  'use strict';
  var W = window, D = document;
  if (W.__grabAds) return;
  var R = /*RULES*/null;
  if (!R) return;

  // ---- timing log ----
  var log = [];
  function ms() { try { return Math.round(performance.now()); } catch (e) { return 0; } }
  function note(s) { log.push(ms() + 'ms  ' + s); if (log.length > 70) log.shift(); }
  var api = { log: log, rev: R.rev, early: D.readyState === 'loading', state: function () { return ''; } };
  try { Object.defineProperty(W, '__grabAds', { value: api }); } catch (e) { W.__grabAds = api; }
  note('Grab advert script started (' + (api.early ? 'before the page' : 'after the page had loaded') + ')');

  // ---- 1. remove advert instructions ----
  function split(p) { return String(p).split('.'); }
  var keys = R.keys || [], holders = R.holders || [];
  var paths = (R.paths || []).map(split);
  var drops = (R.drop || []).map(function (d) { return { list: split(d.list), when: split(d.when) }; });
  var removed = 0;

  function walk(o, parts) {
    for (var i = 0; i < parts.length; i++) {
      if (!o || typeof o !== 'object') return undefined;
      o = o[parts[i]];
    }
    return o;
  }
  function strip(o) {
    var n = 0;
    if (!o || typeof o !== 'object') return 0;
    for (var i = 0; i < keys.length; i++) {
      if (o[keys[i]] !== undefined) {
        try { delete o[keys[i]]; } catch (e) { }
        if (o[keys[i]] !== undefined) { try { o[keys[i]] = undefined; } catch (e) { } }
        n++;
      }
    }
    return n;
  }
  function cleanOne(o) {
    var n = strip(o), i, j;
    for (i = 0; i < holders.length; i++) n += strip(o[holders[i]]);
    for (i = 0; i < paths.length; i++) n += strip(walk(o, paths[i]));
    for (i = 0; i < drops.length; i++) {
      var list = walk(o, drops[i].list);
      if (Array.isArray(list)) for (j = list.length - 1; j >= 0; j--) {
        if (walk(list[j], drops[i].when)) { list.splice(j, 1); n++; }
      }
    }
    return n;
  }
  function clean(o, where) {
    var n = 0;
    try {
      if (!o || typeof o !== 'object') return 0;
      if (Array.isArray(o)) {
        for (var i = 0; i < o.length && i < 40; i++) {
          if (o[i] && typeof o[i] === 'object' && !Array.isArray(o[i])) n += cleanOne(o[i]);
        }
      } else n = cleanOne(o);
    } catch (e) { }
    if (n) {
      removed += n;
      note('removed ' + n + ' advert instruction' + (n > 1 ? 's' : '') + ' from ' + where);
    }
    return n;
  }
  // Wraps a built-in function so the result can be looked at; the wrapper still reads as the original.
  function hook(owner, name, after) {
    try {
      var orig = owner[name];
      if (typeof orig !== 'function') return;
      owner[name] = new Proxy(orig, {
        apply: function (target, self, args) {
          var r = Reflect.apply(target, self, args);
          try { var x = after(r); if (x !== undefined) r = x; } catch (e) { }
          return r;
        }
      });
    } catch (e) { }
  }
  function trap(name) {
    try {
      var val = W[name];
      clean(val, name);
      Object.defineProperty(W, name, {
        configurable: true, enumerable: true,
        get: function () { return val; },
        set: function (x) { clean(x, name); val = x; }
      });
    } catch (e) { }
  }
  if (R.prune) {
    hook(JSON, 'parse', function (r) { clean(r, 'page data'); });
    if (W.Response && W.Response.prototype) hook(W.Response.prototype, 'json', function (p) {
      if (p && typeof p.then === 'function') return p.then(function (o) { clean(o, 'a reply from YouTube'); return o; });
    });
    (R.globals || []).forEach(trap);

    // YouTube holds the video back on a fixed timer when it has no advert to show. Cut that wait short.
    var timers = R.timers || [];
    if (timers.length) {
      try {
        var fnText = Function.prototype.toString;
        W.setTimeout = new Proxy(W.setTimeout, {
          apply: function (target, self, args) {
            try {
              for (var i = 0; i < timers.length; i++) {
                var t = timers[i];
                if (args[1] === t.ms && typeof args[0] === 'function' && fnText.call(args[0]).indexOf(t.match) >= 0) {
                  args[1] = t.to;
                  note('cut a ' + t.ms + 'ms wait down to ' + t.to + 'ms');
                  break;
                }
              }
            } catch (e) { }
            return Reflect.apply(target, self, args);
          }
        });
      } catch (e) { }
    }
  }

  // ---- 2. cover and skip an advert that starts anyway ----
  var adClass = R.adClass || [], skipSel = (R.skip || []).join(','), giveUp = R.giveUpMs || 8000;
  var styled = false;
  function addStyle() {
    if (styled) return;
    var root = D.head || D.documentElement;
    if (!root) return;
    var css = '';
    if ((R.hide || []).length) css += R.hide.join(',') + '{display:none!important}';
    if (adClass.length) css += adClass.map(function (c) { return '.html5-video-player.' + c + ':not(.grab-show)::after'; }).join(',') +
      '{content:"Skipping advert\\2026";position:absolute;left:0;top:0;right:0;bottom:0;z-index:2147483000;background:#000;color:#fff;' +
      'display:flex;align-items:center;justify-content:center;font:500 15px/1.3 Roboto,Arial,sans-serif}';
    if (!css) { styled = true; return; }
    try {
      var st = D.createElement('style');
      st.textContent = css;
      root.appendChild(st);
      styled = true;
    } catch (e) { }
  }

  var adSince = 0, adCount = 0, mutedByUs = false, fastByUs = false, sawMeta = false, sawSeek = false, sawClick = false;
  var watched = null, heard = null, lastHref = '', playingNoted = true;

  function inAd(p) {
    for (var i = 0; i < adClass.length; i++) if (p.classList.contains(adClass[i])) return true;
    return false;
  }
  function describe(v) {
    if (!v) return 'no video element';
    return 'paused=' + v.paused + ' ready=' + v.readyState + ' at=' + (Math.round(v.currentTime * 10) / 10) +
      's of ' + (isFinite(v.duration) ? Math.round(v.duration * 10) / 10 + 's' : 'unknown') + ' muted=' + v.muted + ' rate=' + v.playbackRate;
  }
  api.state = function () {
    var p = D.querySelector('.html5-video-player');
    if (!p) return 'no player on the page';
    return 'advert showing=' + inAd(p) + ' | adverts met=' + adCount + ' | instructions removed=' + removed +
      ' | ' + describe(p.querySelector('video')) + ' | player class=' + String(p.className).slice(0, 160);
  };

  function act() {
    addStyle();
    if (location.href !== lastHref) {
      lastHref = location.href;
      playingNoted = false;
      note('opened ' + (location.pathname + location.search).slice(0, 60));
    }
    var p = D.querySelector('.html5-video-player');
    if (!p) return;
    if (p !== watched) {
      watched = p;
      try { new MutationObserver(act).observe(p, { attributes: true, attributeFilter: ['class'] }); } catch (e) { }
    }
    var v = p.querySelector('video');
    if (v && v !== heard) {
      heard = v;
      ['loadedmetadata', 'durationchange', 'canplay', 'playing', 'timeupdate', 'ended'].forEach(function (n) {
        try { v.addEventListener(n, act, true); } catch (e) { }
      });
    }
    var now = Date.now();
    if (inAd(p)) {
      if (!adSince) {
        adSince = now; adCount++; sawMeta = sawSeek = sawClick = false;
        p.classList.remove('grab-show');
        note('advert ' + adCount + ' started: ' + describe(v));
      }
      if (v) {
        if (!v.muted) { v.muted = true; mutedByUs = true; }
        var d = v.duration;
        if (isFinite(d) && d > 0) {
          if (!sawMeta) { sawMeta = true; note('advert loaded, ' + Math.round(d) + 's long'); }
          try { if (v.playbackRate < 16) { v.playbackRate = 16; fastByUs = true; } } catch (e) { }
          if (v.currentTime < d - 0.3) {
            try { v.currentTime = d; } catch (e) { }
            if (!sawSeek) { sawSeek = true; note('jumped the advert to its end'); }
          }
        }
      }
      if (skipSel) {
        var b = p.querySelectorAll(skipSel);
        for (var i = 0; i < b.length; i++) { try { b[i].click(); } catch (e) { } }
        if (b.length && !sawClick) { sawClick = true; note('pressed Skip'); }
      }
      // Not getting anywhere: take the cover away so the advert and its own Skip button can be used.
      if (now - adSince > giveUp && !p.classList.contains('grab-show')) {
        p.classList.add('grab-show');
        note('advert still there after ' + giveUp + 'ms, cover removed: ' + describe(v));
      }
    } else {
      if (adSince) {
        note('advert ' + adCount + ' over after ' + (now - adSince) + 'ms');
        adSince = 0;
        playingNoted = false;
      }
      if (v) {
        if (mutedByUs) { v.muted = false; mutedByUs = false; }
        if (fastByUs) { fastByUs = false; try { if (v.playbackRate === 16) v.playbackRate = 1; } catch (e) { } }
        if (!playingNoted && !v.paused && v.readyState > 2 && v.currentTime > 0) {
          playingNoted = true;
          note('video playing');
        }
      }
    }
  }
  setInterval(act, 150);
  try { D.addEventListener('DOMContentLoaded', act); } catch (e) { }
  act();
})();
